#!/usr/bin/env bash
love steel-arena.love --server
